let catatan = [
  {
    Judul: "Catatan",
    Isi: [
      "Terbuka untuk mahasiswa UMN angkatan 2021 dan 2022.",
      "Semua informasi <b>WAJIB</b> diisi kecuali bagian prestasi yang bersifat optional.",
      "Foto yang dilampirkan <b>WAJIB</b> ukuran 3x4 cm, foto berwarna dan terbaru (maksimal 1 bulan).",
      "Lampirkan screenshot Personality Test lengkap dengan persentasenya.",
      "Lampirkan screenshot Grades dari myumn.",
      "Lampirkan 1 lembar fotokopi Kartu Mahasiswa.",
      "Formulir dan semua berkas dikumpulkan dalam link google form yang sudah disediakan.",
      "Pengumpulan formulir paling lambat Kamis, 04 Mei 2023.",
      "Peserta yang lolos ke tahap berikutnya akan diumumkan melalui email student dan website Mr. & Ms. UMN 2023.",
      "Peserta yang lolos WAJIB mengikuti tahap seleksi pada hari Senin, 15 Mei 2023.",
      "Dresscode untuk tahap seleksi:",
      [
        "Blouse/kemeja putih sopan",
        "Jeans berwarna gelap sopan",
        "Pantofel/Sneakers (laki-laki)",
        "Heels tertutup min. 5 cm (perempuan)",
        "Make Up natural",
      ],
      "Untuk informasi lebih lanjut hubungi via dm Instagram: @mrmsumn.",
    ],
  },
];

let kriteria = [
  {
    Judul: "KRITERIA CALON Mr. & Ms. UMN 2023",
    Isi: [
      "Mahasiswa aktif Universitas Multimedia Nusantara angkatan 2021-2022.",
      "Memiliki IPK minimum 3.30.",
      "Belum menikah.",
      "Ketentuan tinggi untuk calon kandidat laki-laki 165 cm dan calon kandidat perempuan 155 cm dengan berat badan proposional.",
      "Berkepribadian baik, percaya diri, berpenampilan menarik, berbakat, inspiratif, dan komunikatif.",
      "Memiliki wawasan dan pengetahuan yang baik tentang Universitas Multimedia Nusantara.",
      "Menguasai Bahasa Indonesia yang baik dan benar  (menguasai bahasa asing akan menjadi nilai tambah).",
      "Memiliki pengalaman berorganisasi didalam atau diluar kampus menjadi nilai tambah.",
      "Sehat jasmani dan rohani (Bebas dari NAPZA, miras, dan rokok/vape).",
      "Bersedia menghitamkan warna rambut, jika memiliki rambut yang berwarna. ",
      "Tidak pernah ikut serta dalam kepanitiaan Mr. & Ms. UMN 2020-2022, BEM dan DKBM.",
      "Bersedia menjalankan tugas dan kewajiban selama 1 tahun jabatan jika terpilih sebagai finalis Mr. & Ms. UMN 2023.",
    ],
  },
];
