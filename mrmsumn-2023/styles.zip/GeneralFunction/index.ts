export { onPause, onPlay } from "./PlayPause";
